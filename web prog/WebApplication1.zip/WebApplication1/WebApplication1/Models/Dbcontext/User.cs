﻿using System.ComponentModel.DataAnnotations;

public class User
{
    [Key]
    public int ID { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; }

    [Required]
    [StringLength(100)]
    [EmailAddress]
    public string Email { get; set; }

    [Required]
    [StringLength(256)]
    public string Password { get; set; }

    [Required]
    [StringLength(20)]
    public string Role { get; set; } // "Admin" veya "Member"

    public DateTime CreatedDate { get; set; } = DateTime.Now;

    // Randevular (Appointments) ile ilişki
    public ICollection<Appointment> Appointments { get; set; }
}
