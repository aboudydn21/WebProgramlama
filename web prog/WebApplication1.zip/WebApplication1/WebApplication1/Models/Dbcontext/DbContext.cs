﻿namespace WebApplication1.Models.Dbcontext
{
    public class DbContext
    {
    }
}
