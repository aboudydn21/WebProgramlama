﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Appointment
{
    [Key]
    public int ID { get; set; }

    [ForeignKey("User")]
    public int UserID { get; set; } // Randevu alan kullanıcının ID’si
    public User User { get; set; } // Navigation property

    [ForeignKey("Employee")]
    public int EmployeeID { get; set; } // İşlemi yapacak çalışanın ID’si
    public Employee Employee { get; set; } // Navigation property

    [ForeignKey("Service")]
    public int ServiceID { get; set; } // Seçilen hizmetin ID’si
    public Service Service { get; set; } // Navigation property

    [Required]
    public DateTime Date { get; set; } // Randevu tarihi ve saati

    [StringLength(20)]
    public string Status { get; set; } = "Pending"; // Randevu durumu (Bekliyor, Onaylandı, İptal Edildi)
}
