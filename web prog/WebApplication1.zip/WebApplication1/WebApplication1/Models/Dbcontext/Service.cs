﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Service
{
    [Key]
    public int ID { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; } // Örneğin: Saç Kesimi

    [Required]
    public int Duration { get; set; } // Dakika cinsinden işlem süresi

    [Required]
    public decimal Price { get; set; } // İşlem ücreti

    [ForeignKey("Salon")]
    public int SalonID { get; set; } // İşlemi sunan salonun ID’si
    public Salon Salon { get; set; } // Navigation property

    // Randevular (Appointments) ile ilişki
    public ICollection<Appointment> Appointments { get; set; }
}
