﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Employee
{
    [Key]
    public int ID { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; }

    [StringLength(200)]
    public string Specialty { get; set; } // Uzmanlık alanları (örn: Saç Kesimi, Boya)

    [StringLength(50)]
    public string Availability { get; set; } // Örneğin: "10:00-18:00"

    [ForeignKey("Salon")]
    public int SalonID { get; set; } // Çalıştığı salonun ID’si
    public Salon Salon { get; set; } // Navigation property

    // Randevular (Appointments) ile ilişki
    public ICollection<Appointment> Appointments { get; set; }
}
