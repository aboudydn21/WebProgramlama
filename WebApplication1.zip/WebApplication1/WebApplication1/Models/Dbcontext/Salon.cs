﻿using System.ComponentModel.DataAnnotations;

public class Salon
{
    [Key]
    public int ID { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; }

    [StringLength(50)]
    public string WorkingHours { get; set; } // Örneğin: "09:00-20:00"

    [StringLength(250)]
    public string Address { get; set; }

    [StringLength(20)]
    public string PhoneNumber { get; set; }

    // Çalışanlar (Employees) ve İşlemler (Services) ile ilişki
    public ICollection<Employee> Employees { get; set; }
    public ICollection<Service> Services { get; set; }
}
